package file;

import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Read_Write {
	public static void main(String[] args) throws IOException { 
        FileReader fr = null; 
        FileWriter fw = null; 
        try { 
            System.out.println("Enter Existing Source File "); 
            String file1=extracted().next(); 
            fr = new FileReader(file1); 
            System.out.println("Enter Destination"); 
            String file2=extracted().next();

            File f2=new File(file2); 
            if(!f2.exists()) { 
                fw = new FileWriter(file2); 
                f2.createNewFile(); 
                int c = fr.read(); 
                while(c!=-1) { 
                    fw.write(c); 
                    c = fr.read(); 
                } 
                System.out.println("File Successfully Copied"); 
            } else { 
                fw = new FileWriter(file2); 
                System.out.println("Do you want to Overwrite ? Enter 'Yes' or 'No'  "); 
                char ans = extracted().next().charAt(2);
                

                if(ans=='N'||ans=='n') { 
                    System.out.println("Error Data Entry"); 
                } else { 
                    int c = fr.read(); 
                    while(c!=-1) { 
                        fw.write(c); 
                        c = fr.read(); 
                    } 
                    System.out.println("File updated Successfully"); 
                } 
            } 
        } catch(IOException e) { 
            System.out.println("File Not Found"); 
        } finally { 
            close(fr); 
            close(fw); 
        } 
    }
	private static Scanner extracted() {
		return new Scanner(System.in);
	} 
    public static void close(Closeable stream) { 
        try { 
            if (stream != null) { 
                stream.close(); 
            } 
        } catch(IOException e) { //... } 
    } 
    }
}
