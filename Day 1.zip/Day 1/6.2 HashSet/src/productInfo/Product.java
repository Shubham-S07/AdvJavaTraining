package productInfo;

import java.util.Hashtable;
import java.util.Scanner;

public class Product {
	private static Scanner sc;

	public static void main(String[] args) {
		sc = new Scanner(System.in);
		Hashtable<String,String> hm=new Hashtable<String,String>();
		System.out.println("Enter The Product ID & Name : ");
		for(int i=0;i<4;i++)
		{
			hm.put(sc.nextLine(),sc.nextLine());
		}
		System.out.println("The Product List is:");
		System.out.println(hm);
		System.out.println("Enter the Product ID to be Removed:");
		String id = sc.next();
		hm.remove(id);
		System.out.println("Item Removed");
		System.out.println("The product list is:");
		System.out.println(hm.toString());
		System.out.println("Enter the Product ID to be Searched:");
		String sid=sc.next();
		if(hm.containsKey(sid))
		{
			System.out.println(hm.get(sid));
		}
		else {
			System.out.println("Does not exist");
		}
	}
}
