package studentNames;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Student {
	public static void main (String[] args) {
		 ArrayList<String> a1=new ArrayList<String>();
	 int n;
	 System.out.println("Enter the number of students");
	 n=extracted().nextInt();
	 System.out.println("Enter the student names");
	for(int i=0;i<n;i++)
	{
		a1.add(extracted().next());
	}
	System.out.println("Student List :" +a1);
	for (int i = 0; i < a1.size(); i++) {
		System.out.println("Enter the name of the student : ");
		String st=extracted().next(); 
		int position=Collections.binarySearch(a1,st);
		System.out.println("Posistion of "+ st +" is : "+position);
	}
	 }

	private static Scanner extracted() {
		return new Scanner(System.in);
	}
}
