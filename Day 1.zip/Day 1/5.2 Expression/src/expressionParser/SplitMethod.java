package expressionParser;

import java.util.Scanner;

public class SplitMethod {
	private static Scanner sc;

	public static void main(String[] args) {
		while(true) {
		System.out.println("Enter the Expressions");
		sc = new Scanner(System.in);
		String a = sc.nextLine();
		String[] b= a.split("\\s");
		for(String c:b) {
			System.out.println(c);
		}
	}
  }
}
