package fibonacciSeries;

import java.util.Scanner;
	public class Fibo {
		 private static Scanner scanner;
			private static Scanner scanner2;
		public static void main(String[] args) { 
			scanner = new Scanner(System.in);
			   System.out.println("Enter the Number : ");
			   int num1=scanner.nextInt();
			   
			   setScanner2(new Scanner(System.in));
			   System.out.println("Enter the Number :");
			   int num2=scanner.nextInt();
			    
			int num3;
			System.out.print(num1+" "+num2);
			for(int i=0;i<13;i++) { 
				num3=num1+num2; 
				System.out.print(" "+num3);
				num1=num2; 
				num2=num3; 
				} 
		}
		public static Scanner getScanner2() {
			return scanner2;
		}

		public static void setScanner2(Scanner scanner2) {
			Fibo.scanner2 = scanner2;
	}
	}