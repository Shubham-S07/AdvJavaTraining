package phoneBook;

import java.util.HashMap;
import java.util.Scanner;

public class Contact {
	public static String help_msg=	" \n Select \n A  Add Contact  \n S  Search  \n Q  Quit :";
	public static void main(String[] args) {		
		System.out.println("\n ----PhoneBook Directory---- \n");
		HashMap<String , String> map1 = new HashMap<>();
		for(;;){
				System.out.print("[Main Menu] "+help_msg+"\n:");
				String command=extracted().nextLine().trim();				
 
				if (command.equalsIgnoreCase("A")){
					System.out.print("Enter Contact Information as : Name,Phone Number \n:");
					map1.put(extracted().nextLine(),extracted().nextLine());
					
					System.out.println(map1);
 
				}else if (command.equalsIgnoreCase("S")){
					System.out.print("Enter the Name of the Person :\n:");
					String sid= extracted().nextLine();
					if(map1.containsKey(sid)) {
						System.out.println(map1.get(sid));
					}
					else {
						 System.out.println("No Value");
					}
						
 
				}else if (command.equalsIgnoreCase("Q")){
					System.out.println("Terminated.");
					System.exit(0);
				}else{					
					System.out.print("ERROR! Try again \n:");
				}
 
		}
 
	}
	private static Scanner extracted() {
		return new Scanner(System.in);
	}
}
