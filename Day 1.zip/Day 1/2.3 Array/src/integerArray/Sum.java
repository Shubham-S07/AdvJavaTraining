package integerArray;

public class Sum {
	
	public static void main(String[] args)
	{
	int Array[]={3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
	Array[17]=Array[0];
	for(int i=0;i<15;i++)
	{
	Array[15]=Array[15]+Array[i];
	if(Array[i]<Array[17]) Array[17]=Array[i];
	}
	Array[16]=Array[15]/15;
	System.out.println("Sum="+Array[15]);
	System.out.println("Avg="+Array[16]);
	System.out.println("Min="+Array[17]);
	
	}
}
