package employeeDetails;

import java.util.LinkedList;

public class EmployeeTable {
	private static LinkedList<Employee> addInput() {
		Employee e1 = new Employee(001, "Jayesh","Pune");
		Employee e2 = new Employee(002, "Arun","Hyderabad");
		Employee e3 = new Employee(003, "Khilesh","Banglore");
		LinkedList<Employee> e = new LinkedList<>();
		e.add(e1);
		e.add(e2);
		e.add(e3);
		return e;
	}

	public static void display(LinkedList<Employee>v)
	{
		System.out.println("Employee ID \t Employee Name \t Location");
		for(Employee e:v)
		{
			System.out.println(e.getEid()+"\t\t"+e.getEname()+"\t\t"+e.getAddress());
		}
	}

	public static void main(String[]args) {

		LinkedList<Employee> e = addInput();
		display(e);
		
		
	}
}
