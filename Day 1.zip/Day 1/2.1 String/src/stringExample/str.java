package stringExample;

import java.util.Scanner;

public class str {

	
		   public static void main(String args[])
		   {
		      String str, rev = "";
		      try (Scanner sc = new Scanner(System.in)) {
				System.out.println("Enter a string:");
				  str = sc.nextLine();
			}
		 
		      int length = str.length();
		      System.out.println("string length is: "+str.length());
		      String strUpperCase = str.toUpperCase();

				System.out.println("converting String Lower Case to Upper Case: " + strUpperCase);

		 
		      for (int i = length - 1; i >= 0; i--)
		         rev = rev + str.charAt(i);
		 
		      if (str.equals(rev))
		         System.out.println(str+" is a palindrome");
		      else
		         System.out.println(str+" is not a palindrome");
		 
		   }
}
