package rectangle;

public class Rectangle {
	public static void main(String[] args)
	{
	Rect1 first=new Rect1();
	Rect1 second=new Rect1();
	first.set(18,14);
	System.out.println("Length of first ="+first.getl());
	System.out.println("Breadth of first="+first.getb());
	System.out.println("Area of first ="+first.area());
	System.out.println("Perimeter of first="+first.perimeter());
	System.out.println();
	
	second.set(23,3);
	System.out.println("Length of second ="+second.getl());
	System.out.println("Breadth of second="+second.getb());
	System.out.println("Area of second ="+second.area());
	System.out.println("Perimeter of second="+second.perimeter());
	}
}
