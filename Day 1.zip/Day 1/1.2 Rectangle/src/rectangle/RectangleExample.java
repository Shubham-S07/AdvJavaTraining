package rectangle;

class RectangleExample{
float len;
float breadth;
public RectangleExample()
{
len = 0;
breadth = 0;
}
public RectangleExample(float l,float b)
{
len = l;
breadth = b;
}
public void setLength(float l)
{
len = l;
}
public void setBreadth(float b)
{
breadth = b;
}
public float Area()
{
return len*breadth;
}
public float Perimeter()
{
return 2*(len+breadth);
}
public String display()
{
return ("\n Length : "+len+"\t Breadth : "+breadth+"\n Area of Rectangle : "+Area() );
}
public String display1()
{
	return("\n Perimeter of Rectangle : "+Perimeter() );
}
}
