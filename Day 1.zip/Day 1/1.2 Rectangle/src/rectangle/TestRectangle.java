package rectangle;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestRectangle {
	public static void main(String[] args)
			throws IOException
			{
			RectangleExample R[] = new RectangleExample[5];
			for (int i=0; i<R.length ; i++ )
			{
			R[i] = new RectangleExample();
			System.out.println("\n Enter the length and breadth of rectangle["+i+"] : ");
			BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
			String str=b.readLine();
			float f = Float.parseFloat(str);
			R[i].setLength(f);
			
			BufferedReader b1=new BufferedReader(new InputStreamReader(System.in));
			String stfirst=b1.readLine();
			float f1 = Float.parseFloat(stfirst);
			R[i].setBreadth(f1);
			
			System.out.println("\n Rectangle ["+i+"] : "+R[i].display() +R[i].display1());
			
			}
			}
}
