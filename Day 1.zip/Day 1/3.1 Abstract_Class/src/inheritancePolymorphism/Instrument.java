package inheritancePolymorphism;

public abstract class Instrument {
abstract public void play();
}