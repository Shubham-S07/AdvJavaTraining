package medicineInfo;

import java.util.Random;

public class MedicineDemo {
	public static void main(String [] args)
	{
	Medicine med[]=new Medicine[10];
	Random rnd=new Random();
	int num=0;
	for(int i=0;i<10;i++)
	{
	num=rnd.nextInt(3);
	if(num==0)
	med[i]=new tablet("Emcure Pharmaceuticals","Pune");
	else if(num==1)
	med[i]=new syrup("Abott India","Mumbai");
	else
	med[i]=new ointment("Sun Pharmaceutical Industries Ltd. ","Gurugram");
	med[i].displayLabel();
	System.out.println();
	}
	}
}
