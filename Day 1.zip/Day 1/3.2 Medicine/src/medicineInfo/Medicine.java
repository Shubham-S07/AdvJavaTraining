package medicineInfo;

public class Medicine {
	
	String companyName;
	String address;
	Medicine(String x,String y)
	{
	companyName=x;
	address=y;
	}
	public void displayLabel()
	{
	System.out.println("Company Name:"+companyName);
	System.out.println("Address:"+address);
	}
	}

	class tablet extends Medicine
	{
	tablet(String x,String y)
	{
	super(x,y);
	}
	public void displayLabel()
	{
	super.displayLabel();
	System.out.println("Store in a cool place");
	}
	}
	
	class syrup extends Medicine
	{
	syrup(String x,String y)
	{
	super(x,y);
	}
	public void displayLabel()
	{
	super.displayLabel();
	System.out.println("Use: As prescribed by the medical practitioner");
	}
	}
	
	class ointment extends Medicine
	{
	ointment(String x,String y)
	{
	super(x,y);
	}
	public void displayLabel()
	{
	super.displayLabel();
	System.out.println("For external use only");
	}
	}
