

class NameNotValidException extends Exception
{
     private static final long serialVersionUID1 = 7682940887943615175L;
	private static final long serialVersionUID = 7682940887943615175L;

	public String validname()
     {
          return ("Name is not Valid..Please Provide a Correct Name");
     }

	public static long getSerialversionuid1() {
		return serialVersionUID1;
	}
}