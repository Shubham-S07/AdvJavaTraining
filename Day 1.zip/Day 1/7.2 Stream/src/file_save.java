

import java.io.BufferedWriter;
import java.io.FileWriter;

class FileWrite 
{
   public static void main(String args[])
  {
      try{
    // Create file 
    FileWriter fstream = new FileWriter(System.currentTimeMillis() + "out.txt");
        BufferedWriter out = new BufferedWriter(fstream);
    out.write("Welcome World");
    out.close();
    }catch (Exception e){
      System.err.println("Error: " + e.getMessage());
    }
  }
}
