


	class AgeNotEligible extends Exception
	{
	     private static final long serialVersionUID = 1L;

		public String toString()
	     {
	          return ("Age is not between 14 and 23. Please Enter a Correct Age");
	     }
	}