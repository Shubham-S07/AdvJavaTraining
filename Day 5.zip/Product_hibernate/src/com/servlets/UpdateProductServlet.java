package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.entity.Product;
import com.util.HibernateUtil;

/**
 * Servlet implementation class UpdateProductServlet
 */
@WebServlet("/update-product")
public class UpdateProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("update-product.html").include(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				PrintWriter out = response.getWriter();
				String productId = request.getParameter("id");
				String productName = request.getParameter("name");
				String productPrice = request.getParameter("price");
				String productQuantity = request.getParameter("quantity");
				String productCategory = request.getParameter("category");
				String productModel = request.getParameter("model");
				String productBrand = request.getParameter("brand");
				//Step1: Gets session Factory
				SessionFactory sf = HibernateUtil.buildSessionFactory();
				
				//Step 2: Gets Session object
				Session session = sf.openSession();
				
				//Step3: Gets Tx object and begin transaction
				Transaction tx =  session.beginTransaction();
				
				// Step 4: Create and populate entity object
				Product product = new Product();
				product.setId(Integer.parseInt(productId));
				product.setName(productName);
				product.setPrice(Double.parseDouble(productPrice));
				product.setQuantity(productQuantity);
				product.setCategory(productCategory);
				product.setModel(productModel);
				product.setBrand(productBrand);

				
				Product products = (Product) session.createQuery("update product set name=?,price=?,quantity=?,category=?,model=?,brand=? where id=?");
				//Step 5: <h3 style='color:green'> ProductNischith is created successfully ! </h3>Save record in DB
				session.save(product);
				
				tx.commit();
				
				out.print("<h3> Product is updated successfully ! <h3>");
				session.close();
	}

}
