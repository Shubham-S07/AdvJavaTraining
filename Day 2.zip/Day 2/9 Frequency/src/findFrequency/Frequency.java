package findFrequency;

import java.util.HashMap;
import java.util.Map;

public class Frequency {
	public static void findFrequency(int [] n, int l, int r, Map<Integer, Integer> freq) {
		if(l > r) {
			return ;
		}
		if(n[l] == n[r]) {
			Integer count = freq.get(n[l]);
			if(count == null) {
				count = 0;
			}
			freq.put(n[l], count+(r-l +1));
			return ;
		}
		int m = (l+r)/2;
		findFrequency(n, l, m, freq);
		findFrequency(n, m+1, r, freq);
	}

	public static void main(String[] args) {
		int[] n = {2,2,2,4,4,4,5,5,6,8,8,9};
		Map<Integer, Integer> freq = new HashMap<>();
		findFrequency(n, 0, n.length - 1, freq);
		System.out.println(freq);
	}
}
