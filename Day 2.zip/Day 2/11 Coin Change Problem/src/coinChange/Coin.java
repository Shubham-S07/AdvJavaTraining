package coinChange;

import java.util.Scanner;
import java.util.Vector;

public class Coin {
	 static int change[] = {1, 2, 5, 10, 20, 
			    50, 100, 500, 2000};
			    static int n = change.length;
			  
			    static void findMin(int V)
			    {
			   	        Vector<Integer> ans = new Vector<>();
			  
			       	        for (int i = n - 1; i >= 0; i--)
			       	        	{
			           
			       	        		while (V >= change[i]) 
			       	        			{
			       	        					V =V- change[i];
			       	        					ans.add(change[i]);
			       	        			}
			       	        	}
 
			        for (int i = 0; i < ans.size(); i++)
			        {
			            System.out.print(" " + ans.elementAt(i));			            
			        }
			        System.out.println("\n Coins "+ans.size());
			    }
			  
			   
			    public static void main(String[] args) 
			    {
			    	while(true) {
			    	 @SuppressWarnings("resource")
					Scanner scanner=new Scanner(System.in);
			    	   System.out.println("Enter the Number");
			    	   int n=scanner.nextInt();
			        
			    	   
			        System.out.print("Breakdown- " +"for " + n + ":- ");
			        findMin(n);
			    }

			    }
}
